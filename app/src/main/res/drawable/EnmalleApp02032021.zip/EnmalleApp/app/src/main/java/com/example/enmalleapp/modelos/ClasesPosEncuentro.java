package com.example.enmalleapp.modelos;

public class ClasesPosEncuentro {

    private String numeroRedes1;
    private String numeroCelulas1;
    private String tema1;
    private String numeroHombres1;
    private String numeroMujeres1;
    private String numeroAlumnos1;
    private String numeroAsistentesAnterior1;
    private String estadoClase1;

    private String numeroRedes2;
    private String numeroCelulas2;
    private String tema2;
    private String numeroHombres2;
    private String numeroMujeres2;
    private String numeroAlumnos2;
    private String numeroAsistentesAnterior2;
    private String estadoClase2;

    private String numeroRedes3;
    private String numeroCelulas3;
    private String tema3;
    private String numeroHombres3;
    private String numeroMujeres3;
    private String numeroAlumnos3;
    private String numeroAsistentesAnterior3;
    private String estadoClase3;

    private String numeroRedes4;
    private String numeroCelulas4;
    private String tema4;
    private String numeroHombres4;
    private String numeroMujeres4;
    private String numeroAlumnos4;
    private String numeroAsistentesAnterior4;
    private String estadoClase4;

    private String numeroRedes5;
    private String numeroCelulas5;
    private String tema5;
    private String numeroHombres5;
    private String numeroMujeres5;
    private String numeroAlumnos5;
    private String numeroAsistentesAnterior5;
    private String estadoClase5;

    private String numeroRedes6;
    private String numeroCelulas6;
    private String tema6;
    private String numeroHombres6;
    private String numeroMujeres6;
    private String numeroAlumnos6;
    private String numeroAsistentesAnterior6;
    private String estadoClase6;

    private String numeroRedes7;
    private String numeroCelulas7;
    private String tema7;
    private String numeroHombres7;
    private String numeroMujeres7;
    private String numeroAlumnos7;
    private String numeroAsistentesAnterior7;
    private String estadoClase7;

    private String numeroRedes8;
    private String numeroCelulas8;
    private String tema8;
    private String numeroHombres8;
    private String numeroMujeres8;
    private String numeroAlumnos8;
    private String numeroAsistentesAnterior8;
    private String estadoClase8;

    private String numeroRedes9;
    private String numeroCelulas9;
    private String tema9;
    private String numeroHombres9;
    private String numeroMujeres9;
    private String numeroAlumnos9;
    private String numeroAsistentesAnterior9;
    private String estadoClase9;

    public ClasesPosEncuentro() {

    }

    public ClasesPosEncuentro(String numeroRedes1, String numeroCelulas1, String tema1, String numeroHombres1, String numeroMujeres1, String numeroAlumnos1, String numeroAsistentesAnterior1, String estadoClase1, String numeroRedes2, String numeroCelulas2, String tema2, String numeroHombres2, String numeroMujeres2, String numeroAlumnos2, String numeroAsistentesAnterior2, String estadoClase2, String numeroRedes3, String numeroCelulas3, String tema3, String numeroHombres3, String numeroMujeres3, String numeroAlumnos3, String numeroAsistentesAnterior3, String estadoClase3, String numeroRedes4, String numeroCelulas4, String tema4, String numeroHombres4, String numeroMujeres4, String numeroAlumnos4, String numeroAsistentesAnterior4, String estadoClase4, String numeroRedes5, String numeroCelulas5, String tema5, String numeroHombres5, String numeroMujeres5, String numeroAlumnos5, String numeroAsistentesAnterior5, String estadoClase5, String numeroRedes6, String numeroCelulas6, String tema6, String numeroHombres6, String numeroMujeres6, String numeroAlumnos6, String numeroAsistentesAnterior6, String estadoClase6, String numeroRedes7, String numeroCelulas7, String tema7, String numeroHombres7, String numeroMujeres7, String numeroAlumnos7, String numeroAsistentesAnterior7, String estadoClase7, String numeroRedes8, String numeroCelulas8, String tema8, String numeroHombres8, String numeroMujeres8, String numeroAlumnos8, String numeroAsistentesAnterior8, String estadoClase8, String numeroRedes9, String numeroCelulas9, String tema9, String numeroHombres9, String numeroMujeres9, String numeroAlumnos9, String numeroAsistentesAnterior9, String estadoClase9) {
        this.numeroRedes1 = numeroRedes1;
        this.numeroCelulas1 = numeroCelulas1;
        this.tema1 = tema1;
        this.numeroHombres1 = numeroHombres1;
        this.numeroMujeres1 = numeroMujeres1;
        this.numeroAlumnos1 = numeroAlumnos1;
        this.numeroAsistentesAnterior1 = numeroAsistentesAnterior1;
        this.estadoClase1 = estadoClase1;
        this.numeroRedes2 = numeroRedes2;
        this.numeroCelulas2 = numeroCelulas2;
        this.tema2 = tema2;
        this.numeroHombres2 = numeroHombres2;
        this.numeroMujeres2 = numeroMujeres2;
        this.numeroAlumnos2 = numeroAlumnos2;
        this.numeroAsistentesAnterior2 = numeroAsistentesAnterior2;
        this.estadoClase2 = estadoClase2;
        this.numeroRedes3 = numeroRedes3;
        this.numeroCelulas3 = numeroCelulas3;
        this.tema3 = tema3;
        this.numeroHombres3 = numeroHombres3;
        this.numeroMujeres3 = numeroMujeres3;
        this.numeroAlumnos3 = numeroAlumnos3;
        this.numeroAsistentesAnterior3 = numeroAsistentesAnterior3;
        this.estadoClase3 = estadoClase3;
        this.numeroRedes4 = numeroRedes4;
        this.numeroCelulas4 = numeroCelulas4;
        this.tema4 = tema4;
        this.numeroHombres4 = numeroHombres4;
        this.numeroMujeres4 = numeroMujeres4;
        this.numeroAlumnos4 = numeroAlumnos4;
        this.numeroAsistentesAnterior4 = numeroAsistentesAnterior4;
        this.estadoClase4 = estadoClase4;
        this.numeroRedes5 = numeroRedes5;
        this.numeroCelulas5 = numeroCelulas5;
        this.tema5 = tema5;
        this.numeroHombres5 = numeroHombres5;
        this.numeroMujeres5 = numeroMujeres5;
        this.numeroAlumnos5 = numeroAlumnos5;
        this.numeroAsistentesAnterior5 = numeroAsistentesAnterior5;
        this.estadoClase5 = estadoClase5;
        this.numeroRedes6 = numeroRedes6;
        this.numeroCelulas6 = numeroCelulas6;
        this.tema6 = tema6;
        this.numeroHombres6 = numeroHombres6;
        this.numeroMujeres6 = numeroMujeres6;
        this.numeroAlumnos6 = numeroAlumnos6;
        this.numeroAsistentesAnterior6 = numeroAsistentesAnterior6;
        this.estadoClase6 = estadoClase6;
        this.numeroRedes7 = numeroRedes7;
        this.numeroCelulas7 = numeroCelulas7;
        this.tema7 = tema7;
        this.numeroHombres7 = numeroHombres7;
        this.numeroMujeres7 = numeroMujeres7;
        this.numeroAlumnos7 = numeroAlumnos7;
        this.numeroAsistentesAnterior7 = numeroAsistentesAnterior7;
        this.estadoClase7 = estadoClase7;
        this.numeroRedes8 = numeroRedes8;
        this.numeroCelulas8 = numeroCelulas8;
        this.tema8 = tema8;
        this.numeroHombres8 = numeroHombres8;
        this.numeroMujeres8 = numeroMujeres8;
        this.numeroAlumnos8 = numeroAlumnos8;
        this.numeroAsistentesAnterior8 = numeroAsistentesAnterior8;
        this.estadoClase8 = estadoClase8;
        this.numeroRedes9 = numeroRedes9;
        this.numeroCelulas9 = numeroCelulas9;
        this.tema9 = tema9;
        this.numeroHombres9 = numeroHombres9;
        this.numeroMujeres9 = numeroMujeres9;
        this.numeroAlumnos9 = numeroAlumnos9;
        this.numeroAsistentesAnterior9 = numeroAsistentesAnterior9;
        this.estadoClase9 = estadoClase9;
    }

    public String getNumeroRedes1() {
        return numeroRedes1;
    }

    public void setNumeroRedes1(String numeroRedes1) {
        this.numeroRedes1 = numeroRedes1;
    }

    public String getNumeroCelulas1() {
        return numeroCelulas1;
    }

    public void setNumeroCelulas1(String numeroCelulas1) {
        this.numeroCelulas1 = numeroCelulas1;
    }

    public String getTema1() {
        return tema1;
    }

    public void setTema1(String tema1) {
        this.tema1 = tema1;
    }

    public String getNumeroHombres1() {
        return numeroHombres1;
    }

    public void setNumeroHombres1(String numeroHombres1) {
        this.numeroHombres1 = numeroHombres1;
    }

    public String getNumeroMujeres1() {
        return numeroMujeres1;
    }

    public void setNumeroMujeres1(String numeroMujeres1) {
        this.numeroMujeres1 = numeroMujeres1;
    }

    public String getNumeroAlumnos1() {
        return numeroAlumnos1;
    }

    public void setNumeroAlumnos1(String numeroAlumnos1) {
        this.numeroAlumnos1 = numeroAlumnos1;
    }

    public String getNumeroAsistentesAnterior1() {
        return numeroAsistentesAnterior1;
    }

    public void setNumeroAsistentesAnterior1(String numeroAsistentesAnterior1) {
        this.numeroAsistentesAnterior1 = numeroAsistentesAnterior1;
    }

    public String getEstadoClase1() {
        return estadoClase1;
    }

    public void setEstadoClase1(String estadoClase1) {
        this.estadoClase1 = estadoClase1;
    }

    public String getNumeroRedes2() {
        return numeroRedes2;
    }

    public void setNumeroRedes2(String numeroRedes2) {
        this.numeroRedes2 = numeroRedes2;
    }

    public String getNumeroCelulas2() {
        return numeroCelulas2;
    }

    public void setNumeroCelulas2(String numeroCelulas2) {
        this.numeroCelulas2 = numeroCelulas2;
    }

    public String getTema2() {
        return tema2;
    }

    public void setTema2(String tema2) {
        this.tema2 = tema2;
    }

    public String getNumeroHombres2() {
        return numeroHombres2;
    }

    public void setNumeroHombres2(String numeroHombres2) {
        this.numeroHombres2 = numeroHombres2;
    }

    public String getNumeroMujeres2() {
        return numeroMujeres2;
    }

    public void setNumeroMujeres2(String numeroMujeres2) {
        this.numeroMujeres2 = numeroMujeres2;
    }

    public String getNumeroAlumnos2() {
        return numeroAlumnos2;
    }

    public void setNumeroAlumnos2(String numeroAlumnos2) {
        this.numeroAlumnos2 = numeroAlumnos2;
    }

    public String getNumeroAsistentesAnterior2() {
        return numeroAsistentesAnterior2;
    }

    public void setNumeroAsistentesAnterior2(String numeroAsistentesAnterior2) {
        this.numeroAsistentesAnterior2 = numeroAsistentesAnterior2;
    }

    public String getEstadoClase2() {
        return estadoClase2;
    }

    public void setEstadoClase2(String estadoClase2) {
        this.estadoClase2 = estadoClase2;
    }

    public String getNumeroRedes3() {
        return numeroRedes3;
    }

    public void setNumeroRedes3(String numeroRedes3) {
        this.numeroRedes3 = numeroRedes3;
    }

    public String getNumeroCelulas3() {
        return numeroCelulas3;
    }

    public void setNumeroCelulas3(String numeroCelulas3) {
        this.numeroCelulas3 = numeroCelulas3;
    }

    public String getTema3() {
        return tema3;
    }

    public void setTema3(String tema3) {
        this.tema3 = tema3;
    }

    public String getNumeroHombres3() {
        return numeroHombres3;
    }

    public void setNumeroHombres3(String numeroHombres3) {
        this.numeroHombres3 = numeroHombres3;
    }

    public String getNumeroMujeres3() {
        return numeroMujeres3;
    }

    public void setNumeroMujeres3(String numeroMujeres3) {
        this.numeroMujeres3 = numeroMujeres3;
    }

    public String getNumeroAlumnos3() {
        return numeroAlumnos3;
    }

    public void setNumeroAlumnos3(String numeroAlumnos3) {
        this.numeroAlumnos3 = numeroAlumnos3;
    }

    public String getNumeroAsistentesAnterior3() {
        return numeroAsistentesAnterior3;
    }

    public void setNumeroAsistentesAnterior3(String numeroAsistentesAnterior3) {
        this.numeroAsistentesAnterior3 = numeroAsistentesAnterior3;
    }

    public String getEstadoClase3() {
        return estadoClase3;
    }

    public void setEstadoClase3(String estadoClase3) {
        this.estadoClase3 = estadoClase3;
    }

    public String getNumeroRedes4() {
        return numeroRedes4;
    }

    public void setNumeroRedes4(String numeroRedes4) {
        this.numeroRedes4 = numeroRedes4;
    }

    public String getNumeroCelulas4() {
        return numeroCelulas4;
    }

    public void setNumeroCelulas4(String numeroCelulas4) {
        this.numeroCelulas4 = numeroCelulas4;
    }

    public String getTema4() {
        return tema4;
    }

    public void setTema4(String tema4) {
        this.tema4 = tema4;
    }

    public String getNumeroHombres4() {
        return numeroHombres4;
    }

    public void setNumeroHombres4(String numeroHombres4) {
        this.numeroHombres4 = numeroHombres4;
    }

    public String getNumeroMujeres4() {
        return numeroMujeres4;
    }

    public void setNumeroMujeres4(String numeroMujeres4) {
        this.numeroMujeres4 = numeroMujeres4;
    }

    public String getNumeroAlumnos4() {
        return numeroAlumnos4;
    }

    public void setNumeroAlumnos4(String numeroAlumnos4) {
        this.numeroAlumnos4 = numeroAlumnos4;
    }

    public String getNumeroAsistentesAnterior4() {
        return numeroAsistentesAnterior4;
    }

    public void setNumeroAsistentesAnterior4(String numeroAsistentesAnterior4) {
        this.numeroAsistentesAnterior4 = numeroAsistentesAnterior4;
    }

    public String getEstadoClase4() {
        return estadoClase4;
    }

    public void setEstadoClase4(String estadoClase4) {
        this.estadoClase4 = estadoClase4;
    }

    public String getNumeroRedes5() {
        return numeroRedes5;
    }

    public void setNumeroRedes5(String numeroRedes5) {
        this.numeroRedes5 = numeroRedes5;
    }

    public String getNumeroCelulas5() {
        return numeroCelulas5;
    }

    public void setNumeroCelulas5(String numeroCelulas5) {
        this.numeroCelulas5 = numeroCelulas5;
    }

    public String getTema5() {
        return tema5;
    }

    public void setTema5(String tema5) {
        this.tema5 = tema5;
    }

    public String getNumeroHombres5() {
        return numeroHombres5;
    }

    public void setNumeroHombres5(String numeroHombres5) {
        this.numeroHombres5 = numeroHombres5;
    }

    public String getNumeroMujeres5() {
        return numeroMujeres5;
    }

    public void setNumeroMujeres5(String numeroMujeres5) {
        this.numeroMujeres5 = numeroMujeres5;
    }

    public String getNumeroAlumnos5() {
        return numeroAlumnos5;
    }

    public void setNumeroAlumnos5(String numeroAlumnos5) {
        this.numeroAlumnos5 = numeroAlumnos5;
    }

    public String getNumeroAsistentesAnterior5() {
        return numeroAsistentesAnterior5;
    }

    public void setNumeroAsistentesAnterior5(String numeroAsistentesAnterior5) {
        this.numeroAsistentesAnterior5 = numeroAsistentesAnterior5;
    }

    public String getEstadoClase5() {
        return estadoClase5;
    }

    public void setEstadoClase5(String estadoClase5) {
        this.estadoClase5 = estadoClase5;
    }

    public String getNumeroRedes6() {
        return numeroRedes6;
    }

    public void setNumeroRedes6(String numeroRedes6) {
        this.numeroRedes6 = numeroRedes6;
    }

    public String getNumeroCelulas6() {
        return numeroCelulas6;
    }

    public void setNumeroCelulas6(String numeroCelulas6) {
        this.numeroCelulas6 = numeroCelulas6;
    }

    public String getTema6() {
        return tema6;
    }

    public void setTema6(String tema6) {
        this.tema6 = tema6;
    }

    public String getNumeroHombres6() {
        return numeroHombres6;
    }

    public void setNumeroHombres6(String numeroHombres6) {
        this.numeroHombres6 = numeroHombres6;
    }

    public String getNumeroMujeres6() {
        return numeroMujeres6;
    }

    public void setNumeroMujeres6(String numeroMujeres6) {
        this.numeroMujeres6 = numeroMujeres6;
    }

    public String getNumeroAlumnos6() {
        return numeroAlumnos6;
    }

    public void setNumeroAlumnos6(String numeroAlumnos6) {
        this.numeroAlumnos6 = numeroAlumnos6;
    }

    public String getNumeroAsistentesAnterior6() {
        return numeroAsistentesAnterior6;
    }

    public void setNumeroAsistentesAnterior6(String numeroAsistentesAnterior6) {
        this.numeroAsistentesAnterior6 = numeroAsistentesAnterior6;
    }

    public String getEstadoClase6() {
        return estadoClase6;
    }

    public void setEstadoClase6(String estadoClase6) {
        this.estadoClase6 = estadoClase6;
    }

    public String getNumeroRedes7() {
        return numeroRedes7;
    }

    public void setNumeroRedes7(String numeroRedes7) {
        this.numeroRedes7 = numeroRedes7;
    }

    public String getNumeroCelulas7() {
        return numeroCelulas7;
    }

    public void setNumeroCelulas7(String numeroCelulas7) {
        this.numeroCelulas7 = numeroCelulas7;
    }

    public String getTema7() {
        return tema7;
    }

    public void setTema7(String tema7) {
        this.tema7 = tema7;
    }

    public String getNumeroHombres7() {
        return numeroHombres7;
    }

    public void setNumeroHombres7(String numeroHombres7) {
        this.numeroHombres7 = numeroHombres7;
    }

    public String getNumeroMujeres7() {
        return numeroMujeres7;
    }

    public void setNumeroMujeres7(String numeroMujeres7) {
        this.numeroMujeres7 = numeroMujeres7;
    }

    public String getNumeroAlumnos7() {
        return numeroAlumnos7;
    }

    public void setNumeroAlumnos7(String numeroAlumnos7) {
        this.numeroAlumnos7 = numeroAlumnos7;
    }

    public String getNumeroAsistentesAnterior7() {
        return numeroAsistentesAnterior7;
    }

    public void setNumeroAsistentesAnterior7(String numeroAsistentesAnterior7) {
        this.numeroAsistentesAnterior7 = numeroAsistentesAnterior7;
    }

    public String getEstadoClase7() {
        return estadoClase7;
    }

    public void setEstadoClase7(String estadoClase7) {
        this.estadoClase7 = estadoClase7;
    }

    public String getNumeroRedes8() {
        return numeroRedes8;
    }

    public void setNumeroRedes8(String numeroRedes8) {
        this.numeroRedes8 = numeroRedes8;
    }

    public String getNumeroCelulas8() {
        return numeroCelulas8;
    }

    public void setNumeroCelulas8(String numeroCelulas8) {
        this.numeroCelulas8 = numeroCelulas8;
    }

    public String getTema8() {
        return tema8;
    }

    public void setTema8(String tema8) {
        this.tema8 = tema8;
    }

    public String getNumeroHombres8() {
        return numeroHombres8;
    }

    public void setNumeroHombres8(String numeroHombres8) {
        this.numeroHombres8 = numeroHombres8;
    }

    public String getNumeroMujeres8() {
        return numeroMujeres8;
    }

    public void setNumeroMujeres8(String numeroMujeres8) {
        this.numeroMujeres8 = numeroMujeres8;
    }

    public String getNumeroAlumnos8() {
        return numeroAlumnos8;
    }

    public void setNumeroAlumnos8(String numeroAlumnos8) {
        this.numeroAlumnos8 = numeroAlumnos8;
    }

    public String getNumeroAsistentesAnterior8() {
        return numeroAsistentesAnterior8;
    }

    public void setNumeroAsistentesAnterior8(String numeroAsistentesAnterior8) {
        this.numeroAsistentesAnterior8 = numeroAsistentesAnterior8;
    }

    public String getEstadoClase8() {
        return estadoClase8;
    }

    public void setEstadoClase8(String estadoClase8) {
        this.estadoClase8 = estadoClase8;
    }

    public String getNumeroRedes9() {
        return numeroRedes9;
    }

    public void setNumeroRedes9(String numeroRedes9) {
        this.numeroRedes9 = numeroRedes9;
    }

    public String getNumeroCelulas9() {
        return numeroCelulas9;
    }

    public void setNumeroCelulas9(String numeroCelulas9) {
        this.numeroCelulas9 = numeroCelulas9;
    }

    public String getTema9() {
        return tema9;
    }

    public void setTema9(String tema9) {
        this.tema9 = tema9;
    }

    public String getNumeroHombres9() {
        return numeroHombres9;
    }

    public void setNumeroHombres9(String numeroHombres9) {
        this.numeroHombres9 = numeroHombres9;
    }

    public String getNumeroMujeres9() {
        return numeroMujeres9;
    }

    public void setNumeroMujeres9(String numeroMujeres9) {
        this.numeroMujeres9 = numeroMujeres9;
    }

    public String getNumeroAlumnos9() {
        return numeroAlumnos9;
    }

    public void setNumeroAlumnos9(String numeroAlumnos9) {
        this.numeroAlumnos9 = numeroAlumnos9;
    }

    public String getNumeroAsistentesAnterior9() {
        return numeroAsistentesAnterior9;
    }

    public void setNumeroAsistentesAnterior9(String numeroAsistentesAnterior9) {
        this.numeroAsistentesAnterior9 = numeroAsistentesAnterior9;
    }

    public String getEstadoClase9() {
        return estadoClase9;
    }

    public void setEstadoClase9(String estadoClase9) {
        this.estadoClase9 = estadoClase9;
    }
}
